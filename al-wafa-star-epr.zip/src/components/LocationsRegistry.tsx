import { useState, Dispatch, SetStateAction } from "react";
import {
  Plus,
  Trash2,
  MapPin,
  Undo,
  Search,
  ExternalLink,
  FileSpreadsheet,
  Sparkles,
} from "lucide-react";
import { LocationRegistryItem, getCurrentUserPermissions } from "../types";
import {
  deleteDocument,
  saveDocument,
  saveDocumentsBulk,
} from "../localDatabase";

export const INITIAL_LOCATIONS_REGISTRY: LocationRegistryItem[] = [];

interface LocationsRegistryProps {
  language: "en" | "ar" | "bn";
  locations: LocationRegistryItem[];
  setLocations: Dispatch<SetStateAction<LocationRegistryItem[]>>;
  loggedInUser?: any;
}

export default function LocationsRegistry({
  language,
  locations,
  setLocations,
  loggedInUser: propLoggedInUser
}: LocationsRegistryProps) {
  const loggedInUserStrRaw = localStorage.getItem("ALW_STAR_LOGGED_IN_USER") || sessionStorage.getItem("ALW_STAR_LOGGED_IN_USER") || localStorage.getItem("ALW_LOGGED_IN_USER_V2");
  let localLoggedInUser = null;
  if (loggedInUserStrRaw) {
    try {
      localLoggedInUser = JSON.parse(loggedInUserStrRaw);
    } catch(err) {}
  }
  const loggedInUser = propLoggedInUser || localLoggedInUser;
  const perms = getCurrentUserPermissions();
  const canAdd = perms.canCreateLocation ?? perms.canManageLocations;
  const canEdit = perms.canEditLocation ?? perms.canManageLocations;
  const canDelete = perms.canDeleteLocation ?? perms.canManageLocations;

  const triggerToast = (msg: string) => {
    setSaveStatus(msg);
    setTimeout(() => setSaveStatus(null), 3000);
  };

  const handleAction = (action: () => void) => {
    if (!canEdit) {
      triggerToast(language === "bn" ? "ভিজিটর মোডে এই কাজ করার অনুমতি নেই!" : "Action not permitted in Visitor mode!");
      return;
    }
    action();
  };

  const [searchTerm, setSearchTerm] = useState("");
  const [emirateFilter, setEmirateFilter] = useState("ALL");
  const [saveStatus, setSaveStatus] = useState<string | null>(null);

  const userAllowedEmirates = loggedInUser?.allowedEmirates || [];
  const hasRegionalRestriction = loggedInUser?.role !== "Admin" && userAllowedEmirates.length > 0;

  const EMIRATE_LIST = hasRegionalRestriction
    ? ["ALL", ...userAllowedEmirates]
    : [
        "ALL",
        "Abu Dhabi",
        "Ajman",
        "Sharjah",
        "Dubai",
        "Umm Al Quwain",
        "Ras Al Khaimah",
        "Fujairah",
        "Other",
      ];

  // Quick cell update handler
  const handleCellChange = (
    id: string,
    field: "name" | "mapUrl" | "emirate",
    value: string,
  ) => {
    if (!canEdit) { triggerToast(language === "bn" ? "আপনার তথ্য পরিবর্তনের অনুমতি নেই!" : "Read-only mode (No edit permission)"); return; }
    setLocations((prev) =>
      prev.map((loc) => {
        if (loc.id === id) {
          return { ...loc, [field]: value };
        }
        return loc;
      }),
    );
  };

  // Add new row inside a specific emirate / state
  const handleAddRow = (emirate: string) => {
    if (!canAdd) { triggerToast(language === "bn" ? "আপনার নতুন লোকেশন যোগ করার অনুমতি নেই!" : "Read-only mode (No add permission)"); return; }
    const code = emirate.substring(0, 3).toUpperCase();
    const newId = `LOC-${code}-${Math.floor(100 + Math.random() * 900)}`;
    const newRow: LocationRegistryItem = {
      id: newId,
      name: "",
      emirate: emirate === "ALL" ? "Dubai" : emirate,
      mapUrl: "",
    };
    setLocations((prev) => [...prev, newRow]);
    saveDocument("locations", newId, newRow).catch(console.warn);

    setSaveStatus(
      language === "bn"
        ? "নতুন লাইন যুক্ত হয়েছে!"
        : "New row added successfully!",
    );
    setTimeout(() => setSaveStatus(null), 2000);
  };

  // Delete row
  const handleDeleteRow = (id: string) => {
    if (!canDelete) { triggerToast(language === "bn" ? "আপনার লোকেশন মুছে ফেলার অনুমতি নেই!" : "Read-only mode (No delete permission)"); return; }
    setLocations((prev) => prev.filter((loc) => loc.id !== id));
    deleteDocument("locations", id);
    setSaveStatus(
      language === "bn"
        ? "লোকেশন সফলভাবে মুছে ফেলা হয়েছে!"
        : "Location successfully deleted!",
    );
    setTimeout(() => setSaveStatus(null), 2500);
  };

  // Reset to original factory sheet
  const handleResetToFactory = () => {
    if (!canEdit) { triggerToast(language === "bn" ? "রিসেট করার অনুমতি নেই!" : "Read-only mode (No edit permission)"); return; }
    setLocations(INITIAL_LOCATIONS_REGISTRY);
    saveDocumentsBulk("locations", INITIAL_LOCATIONS_REGISTRY).catch(
      console.warn,
    );
    setSaveStatus(
      language === "bn"
        ? "সিস্টেম ডিফল্ট সফলভাবে রিস্টোর করা হয়েছে!"
        : "Restored to system defaults successfully!",
    );
    setTimeout(() => setSaveStatus(null), 2500);
  };

  // Filter Locations
  const filteredLocs = locations.filter((loc) => {
    const nameMatch = (loc.name || "")
      .toLowerCase()
      .includes((searchTerm || "").toLowerCase());
    const mapMatch = (loc.mapUrl || "")
      .toLowerCase()
      .includes((searchTerm || "").toLowerCase());
    const matchesSearch = nameMatch || mapMatch;

    const matchesEmirate =
      emirateFilter === "ALL" ||
      (loc.emirate || "").toLowerCase() === (emirateFilter || "").toLowerCase();

    return matchesSearch && matchesEmirate;
  });

  return (
    <div
      id="locations-registry-view"
      className="space-y-6 font-sans text-xs text-slate-150 pb-16"
    >
      {/* Top Title Banner */}
      <div className="bg-[#1E293B]/60 border border-[#334155] rounded-3xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-64 h-64 bg-[#10B981]/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <span className="text-[10px] bg-emerald-500/15 text-[#10B981] font-mono font-black uppercase rounded-full px-3 py-1 tracking-wider border border-emerald-500/30">
              {language === "bn"
                ? "মেডিকেল লোকেশন ও ম্যাপ রেজিস্ট্রি"
                : "Medical Locations & Map Registry"}
            </span>
            <h2 className="text-lg font-black text-slate-100 tracking-tight flex items-center gap-2 mt-2">
              <FileSpreadsheet className="text-[#10B981] w-5.5 h-5.5" />
              <span>
                {language === "bn"
                  ? "লোকেশন ও ম্যাপ নির্দেশিকা (Excel Style)"
                  : "Active Locations Registry Ledger"}
              </span>
            </h2>
            <p className="text-[11px] text-slate-400 mt-1 leading-relaxed max-w-2xl">
              {language === "bn"
                ? "এখানে সরাসরি এক্সেল স্টাইলে হাসপাতাল ও ক্লিনিকের নাম এবং তাদের ম্যাপ লিংক এডিট, ডিলিট এবং নতুন লোকেশন যুক্ত করতে পারবেন। হসপিটালের নাম বা লিংকে ক্লিক করে সরাসরি পরিবর্তন করুন।"
                : "Edit health safety inspection locations and maps links inline. Changes are synchronized automatically."}
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              disabled={!canEdit}
              onClick={handleResetToFactory}
              className={`px-3.5 py-2 hover:bg-slate-800 text-slate-350 hover:text-white rounded-xl text-[11px] font-bold transition flex items-center gap-1.5 cursor-pointer border border-slate-700/60 ${!canEdit ? 'opacity-50 cursor-not-allowed' : ''}`}
              title="Reset to default hospitals list"
            >
              <Undo className="w-4 h-4" />
              <span>
                {language === "bn" ? "ডিফল্ট তালিকা" : "Reset Standard"}
              </span>
            </button>

            <button
              disabled={!canAdd}
              onClick={() => {
                const targetState =
                  emirateFilter === "ALL" ? "Dubai" : emirateFilter;
                handleAddRow(targetState);
              }}
              className={`px-4 py-2 bg-[#10B981] hover:bg-emerald-400 text-slate-950 font-black rounded-xl transition cursor-pointer shadow-lg shadow-emerald-500/10 flex items-center gap-1.5 ${!canAdd ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              <Plus className="w-4 h-4 stroke-[3px]" />
              <span>
                {language === "bn" ? "নতুন লোকেশন যোগ" : "Add Location"}
              </span>
            </button>
          </div>
        </div>

        {/* Filters Toolbar */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6 pt-6 border-t border-slate-705/40">
          <div className="relative">
            <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
            <input
              id="registry-search-box-input"
              type="text"
              placeholder={
                language === "bn"
                  ? "হসপিটাল বা ম্যাপ লিংক খুঁজুন..."
                  : "Search hospital name or google maps url..."
              }
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-950 text-slate-100 border border-slate-700 rounded-xl py-2.5 pl-10 pr-4 text-xs focus:ring-1 focus:ring-[#10B981] focus:border-[#10B981] outline-none placeholder-slate-500"
            />
          </div>

          <div>
            <select
              value={emirateFilter}
              onChange={(e) => setEmirateFilter(e.target.value)}
              className="w-full bg-slate-950 text-slate-100 border border-slate-700 rounded-xl py-2.5 px-3.5 text-xs focus:ring-1 focus:ring-[#10B981] outline-none cursor-pointer"
            >
              {EMIRATE_LIST.map((em) => (
                <option key={em} value={em}>
                  {em === "ALL"
                    ? language === "bn"
                      ? "সকল আমিরাত ফিল্টার"
                      : "All Emirates / Regions"
                    : em.toUpperCase() + " STATE"}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Save Notify */}
      {saveStatus && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 text-[#10B981] rounded-2xl flex items-center gap-2 font-bold animate-pulse text-[11px]">
          <Sparkles className="w-4 h-4 animate-spin text-[#10B981]" />
          <span>{saveStatus}</span>
        </div>
      )}

      {/* Grid Spreadsheet styled */}
      <div className="space-y-8">
        {EMIRATE_LIST.filter((em) => em !== "ALL")
          .filter(
            (em) =>
              emirateFilter === "ALL" ||
              (emirateFilter || "").toLowerCase() === (em || "").toLowerCase(),
          )
          .map((emirateState) => {
            const emirateLocations = filteredLocs.filter((l) => {
              const locEmirate = (l.emirate || "").trim().toLowerCase();
              const currentEmirate = (emirateState || "").trim().toLowerCase();
              if (currentEmirate === "other") {
                const recognizedEmirates = ["abu dhabi", "ajman", "sharjah", "dubai", "umm al quwain", "ras al khaimah", "fujairah"];
                return !locEmirate || !recognizedEmirates.includes(locEmirate);
              }
              return locEmirate === currentEmirate;
            });

            if (emirateLocations.length === 0 && emirateFilter === "ALL")
              return null;

            return (
              <div
                key={emirateState}
                className="bg-[#1E293B]/40 border border-[#334155] rounded-2xl p-4 shadow-sm space-y-3"
              >
                <div className="flex justify-between items-center border-b border-slate-705/50 pb-2">
                  <h3 className="text-xs font-black text-emerald-400 tracking-wide flex items-center gap-1.5 uppercase font-mono">
                    <MapPin className="w-4 h-4 text-emerald-450" />
                    <span>
                      {emirateState === "Dubai"
                        ? "DUBAY / DUBAI"
                        : emirateState === "Sharjah"
                          ? "SHARJHA / SHARJAH"
                          : emirateState}{" "}
                      HOSPITAL DIRECTORY
                    </span>
                    <span className="text-[9px] bg-slate-850 text-[#10B981] border border-emerald-500/20 py-0.5 px-2 rounded-full font-bold">
                      {emirateLocations.length} Registered
                    </span>
                  </h3>
                  <button
                    disabled={!canAdd}
                    onClick={() => handleAddRow(emirateState)}
                    className={`px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-350 hover:text-white rounded-lg text-[9px] font-bold transition flex items-center gap-1 cursor-pointer border border-slate-700 ${!canAdd ? 'opacity-50 cursor-not-allowed' : ''}`}
                  >
                    ➕ Add {emirateState} Row
                  </button>
                </div>

                {emirateLocations.length === 0 ? (
                  <p className="text-[11px] text-slate-500 italic py-2 pl-2">
                    No hospitals matching search in this Emirate.
                  </p>
                ) : (
                  <div className="overflow-x-auto rounded-xl border border-slate-800">
                    <table className="w-full text-slate-200 text-left border-collapse table-auto text-[11px] font-medium min-w-[700px]">
                      <thead>
                        <tr className="bg-slate-950 text-slate-400 font-mono text-[9px] uppercase tracking-wider border-b border-slate-800">
                          <th className="py-2 px-3 border-r border-slate-800 w-12 text-center">
                            S.No
                          </th>
                          <th className="py-2 px-3 border-r border-slate-800 w-64">
                            {language === "bn"
                              ? "হাসপাতাল / ক্লিনিক নাম (এডিট করতে ক্লিক করুন)"
                              : "Hospital / Clinic Name (Click to edit)"}
                          </th>
                          <th className="py-2 px-3 border-r border-slate-800">
                            {language === "bn"
                              ? "গুগল ম্যাপ লিংক / কুঅর্ডিনেট"
                              : "Google Maps URL / Location Link"}
                          </th>
                          <th className="py-2 px-3 text-center w-28">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800">
                        {emirateLocations.map((loc, index) => (
                          <tr
                            key={loc.id}
                            className="hover:bg-slate-800/40 bg-slate-950/20 transition group"
                          >
                            <td className="py-2 px-3 border-r border-slate-800 text-center font-bold text-slate-500 bg-slate-950/40 w-12 font-mono">
                              {index + 1}
                            </td>

                            <td className="py-1.5 px-2 border-r border-slate-800 w-64">
                              <input
                                type="text"
                                value={loc.name}
                                disabled={!canEdit}
                                onChange={(e) =>
                                  handleCellChange(
                                    loc.id,
                                    "name",
                                    e.target.value,
                                  )
                                }
                                onBlur={() => {
                                  if (canEdit) {
                                    saveDocument("locations", loc.id, loc);
                                  }
                                }}
                                placeholder="Type hospital / clinic name..."
                                className={`w-full bg-slate-900 border border-slate-800 text-slate-100 font-bold rounded px-2 py-1 outline-none focus:border-[#10B981] ${!canEdit ? 'opacity-65 cursor-not-allowed' : ''}`}
                              />
                            </td>

                            <td className="py-1.5 px-2 border-r border-slate-800">
                              <div className="flex items-center gap-2">
                                <span className="text-slate-500 select-none">
                                  🗺️
                                </span>
                                {loc.mapUrl && (
                                  <a
                                    href={loc.mapUrl}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="p-1 px-2.5 bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-550/20 rounded transition flex items-center gap-1 cursor-pointer font-bold text-[9px] shrink-0 font-sans"
                                    title="Open coordinates inside maps"
                                  >
                                    <ExternalLink className="w-3 h-3" />
                                    <span>Open</span>
                                  </a>
                                )}
                                <input
                                  type="text"
                                  value={loc.mapUrl || ""}
                                  disabled={!canEdit}
                                  onChange={(e) =>
                                    handleCellChange(
                                      loc.id,
                                      "mapUrl",
                                      e.target.value,
                                    )
                                  }
                                  onBlur={() => {
                                    if (canEdit) {
                                      saveDocument("locations", loc.id, loc);
                                    }
                                  }}
                                  placeholder="Paste google maps link here..."
                                  className={`w-full bg-slate-900 border border-slate-800 text-[#10B981] font-mono text-[10px] rounded px-2 py-1 outline-none focus:border-[#10B981] ${!canEdit ? 'opacity-65 cursor-not-allowed' : ''}`}
                                />
                              </div>
                            </td>

                            <td className="py-1.5 px-2 text-center w-28">
                              <button
                                disabled={!canDelete}
                                onClick={() => handleDeleteRow(loc.id)}
                                className={`px-2.5 py-1 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 rounded transition flex items-center justify-center gap-1 cursor-pointer text-[10px] font-bold mx-auto font-sans ${!canDelete ? 'opacity-40 cursor-not-allowed' : ''}`}
                                title="Delete location row"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                                <span>
                                  {language === "bn" ? "ডিলিট" : "Delete"}
                                </span>
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            );
          })}
      </div>
    </div>
  );
}
